import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:login/ui/shared/globals.dart';

class HomeModel extends ChangeNotifier {

}
